<?php
$loc_id=$_GET['locationid'];
$country=$_GET['country'];
$start=$_GET['start'];
$end=$_GET['end'];
$lat = $_GET["latitude"];
$lon = $_GET["longitude"];

if(!empty ($loc_id))
{
  if (ini_get('date.timezone') =='') 
  {
    date_default_timezone_set('UTC');
  }
$url ="http://history.openweathermap.org/data/2.5/history/city?q=$loc,$country &type=hour &start=$start& end=$end&lat= $lat &lon=$lon &APPID={94091bd0ea7f55df4cf1cf98b528a4a8}";
//$url="http://history.openweathermap.org/data/2.5/history/city?q=London,UK &&APPID= {94091bd0ea7f55df4cf1cf98b528a4a8}";

$contents =file_get_contents($url);
$climate=json_decode($contents);
print_r($climate);
foreach($climate as $value)
{
$img=$climate->weather[0]->icon.".png";
$Maximum_Temperature=$climate->main->temp_max;
$Minimum_Temperature=$climate->main->temp_min;
echo $cityname . " - " .$today . "<br>";
echo "<img src='http://openweathermap.org/img/w/" . $img ."'/>.<br>";
echo 
    "Maximum Temperature : " . $Minimum_Temperature."&deg;C<br>";
echo 
    "Minimum Temperature : " . $Minimum_Temperature."&deg;C<br>";
}

}

?>
