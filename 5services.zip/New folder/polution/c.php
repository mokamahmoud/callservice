<?php
$city_lat=$_GET['lat'];
$city_lon=$_GET['lon'];
$date=$_GET['date'];
if(!empty ($loc)&&!empty ($date))
{
$url="http://api.openweathermap.org/pollution/v1/co/$city_lat,$city_lon/$date.json?appid=94091bd0ea7f55df4cf1cf98b528a4a8";
    
    $contents =file_get_contents($url);
    $climate=json_decode($contents);
    $img=$climate->weather[0]->icon.".png";
    $today = date("F j,Y");
    echo 
    " your city: " .$loc."C<br>";
    echo 
    " Date : " . $date."<br>";


?>
