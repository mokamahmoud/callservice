<?php
 $city_id=$_GET['id'];
if(!empty ($city_id))
{
  if (ini_get('date.timezone') =='') 
  {
    date_default_timezone_set('UTC');
  }
$url ="http://api.openweathermap.org/data/2.5/forecast?id=$city_id&&lang=en&units=metric&APPID=e494a7a1122143263e179f78fc090b96";
$contents =file_get_contents($url);
$climate=json_decode($contents);
    print_r($climate);
    
foreach($climate as $values)
{
$img=$climate->weather[0]->icon.".png";
$today = date("F j,Y");
$cityname = $climate->name;
$Maximum_Temperature=$climate->main[0]->temp_max;
$Minimum_Temperature=$climate->main->temp_min;
echo $cityname . " - " .$today . "<br>";
echo "<img src='http://openweathermap.org/img/w/" . $img ."'/>.<br>";
echo 
    "Maximum Temperature : " . $Minimum_Temperature."&deg;C<br>";
echo 
    "Minimum Temperature : " . $Minimum_Temperature."&deg;C<br>";
}
}
else 
{
    echo "please write city id ";
}
?>